import React from 'react';

const EmptyComponent = () => <div>Empty</div>;

export default EmptyComponent;
