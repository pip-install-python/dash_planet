window.dccFunctions = window.dccFunctions || {};
window.dccFunctions.transformTooltip = function(value) {
    return "Transformed " + value
}
