export default () => import(/* webpackChunkName: "slider" */ '../../fragments/RangeSlider.react');

