export default () => import(/* webpackChunkName: "markdown" */ '../../fragments/Markdown.react');

