Folder to place temporary modules e.g. plotly.js-dist-min in .tgz format
